# ---- eci_long_F.py ---------- Jun.22, 2019 ------ F stands for Final ----
# Source: https://bwinkel.github.io/pycraf/satellite/index.html
from numpy import sqrt, arccos, pi, arctan2
from astropy.coordinates import EarthLocation
from astropy import time
from pycraf import satellite
#
# ECI stands for Earth Center Inertial (frame)
# --------- Step 0 -------------
# Given prediction datetime 
year=2019; month=6; day=16; utch=13; utcm=7; utcs=4
print ('\n Prediction date: ', year, month, day )
print (' Prediction time: ', utch, utcm, utcs, ' UTC' )
print (' ================= ')
# --------- Step 1 -------------
with open ("ST-12giu.txt", "r") as myfile:
    data = myfile.read().splitlines()
for k in range(0,len(data),3):    
	tle= data[k]+'\n'+data[k+1]+'\n'+data[k+2]+'\n'       
	satname, sat = satellite.get_sat(tle)
	print ('\n Name = ', satname,'\n Epoch= ', sat.epoch, '\n Numb = ', sat.satnum)

	# --------- Step 2 ------------
	# using sgp4 directly, to get position and velocity in ECI coordinates
	position, velocity = sat.propagate(year, month, day, utch, utcm, utcs)  
	#
	Long_Sat= arctan2(position[1],position[0])
	if Long_Sat < 0.0:
		Long_Sat= Long_Sat + 2*pi
	print (' Position= ', position, ' km')
#	print (' Longitude=  {:.4f}'.format (Long_Sat*180/pi), ' degs')
# EOF: eci_long_F.py ----------	
