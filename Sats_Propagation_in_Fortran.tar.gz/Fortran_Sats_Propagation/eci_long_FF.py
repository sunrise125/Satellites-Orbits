# ---- eci_long_FF.py ---------- Jun.22-26, 2019 ------ FF stands for Final ----
# Source: https://bwinkel.github.io/pycraf/satellite/index.html
from numpy import sqrt, arccos, pi, arctan2
from astropy.coordinates import EarthLocation
from astropy import time
from pycraf import satellite
#
# ECI stands for Earth Center Inertial (frame)
# --------- Step 0 -------------
# Given prediction datetime 
year=2019; month=6; day=28; utch=2; utcm=2; utcs=54
print ('\n Prediction date: ', year, month, day )
print (' Prediction time: ', utch, utcm, utcs, ' UTC' )
print (' ================= ')
# --------- Step 1 -------------
with open ("28giu.txt", "r") as myfile:
    data = myfile.read().splitlines()
for k in range(0,len(data),3):    
	tle= data[k]+'\n'+data[k+1]+'\n'+data[k+2]+'\n'       
	satname, sat = satellite.get_sat(tle)
	print ('\n Name = ', satname,'\n Epoch= ', sat.epoch, '\n Numb = ', sat.satnum)

	# --------- Step 2 ------------
	# using sgp4 directly, to get position and velocity in ECI coordinates
	position, velocity = sat.propagate(year, month, day, utch, utcm, utcs)  
	#
	Dist_geoc= sqrt (position[0]*position[0]+position[1]*position[1]+position[2]*position[2])
	Long_Sat= arctan2(position[1],position[0])
	if Long_Sat < 0.0:
		Long_Sat= Long_Sat + 2*pi
	print (' Position= ', position, ' km')
	print (' r_geocen= {:.3f}'.format (Dist_geoc), ' km')
	print (' Longitude=  {:.4f}'.format (Long_Sat*180/pi), ' degs')
# EOF: eci_long_FF.py ----------	
'''
 Name =  STARLINK BH
 Epoch=  2019-06-23 20:06:33.651936
 Numb =  44290
 Position=  (6771.701521366504, 1303.1227572275402, -696.965878796731)  km
 r_geocen= 6931.077  km
 Longitude=  10.8926  degs

 Name =  STARLINK BJ
 Epoch=  2019-06-07 11:05:47.381279
 Numb =  44291
 Position=  (nan, nan, nan)  km
 r_geocen= nan  km
 Longitude=  nan  degs

 Name =  STARLINK BK
 Epoch=  2019-06-27 05:11:56.727455
 Numb =  44292
 Position=  (5095.192842898613, 3680.756796744558, 2906.363281237037)  km
 r_geocen= 6925.020  km
 Longitude=  35.8443  degs

'''
