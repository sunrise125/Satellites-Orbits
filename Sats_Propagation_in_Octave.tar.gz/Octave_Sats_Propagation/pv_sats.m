% --------- pv_sats.m ---------- Jun.30-Jul.01, 2019 --------
%
% This script applies the SGP4 propagator.
%
% For setting sgp4init
global tumin mu radiusearthkm xke j2 j3 j4 j3oj2  
% -----------------------------------------------------
%    whichconst = input('input constants 721, 72, 84 ');
    whichconst = 84;
    rad = 180.0 / pi;

%   ---- Setup files for operation: input 2-line element set file -------
	fprintf('\n --- Outputs copied also to file results.txt --- \n');
    infilename = input('input elset filename [try, A-28giu.txt]: ','s');
    infile = fopen(infilename, 'r');
    if (infile == -1)
        fprintf(1,'Failed to open file: %s\n', infilename);
        return;
    end
    % --------- Named output file ---------------
    outfile = fopen('results.txt', 'wt');

    % ---- Input ephemeris date&time ---------    
    JDeph = jday(2019, 6, 28, 2, 2, 54); 
    fprintf('\n JDeph= %16.8f \n\n', JDeph);  
    fprintf(outfile,'\n JDeph= %16.8f \n\n', JDeph); 
    
% ------ Initiatization twoline2rv()
typerun = 'c'; 
typeinput = 'e';
% -------------------------------------------
fprintf(1,'------------------------------------------------------------------------------------------------------\n');
fprintf(1,' Nr.      JD_Epoch           r[km]       rx        ry        rz        v[km/s]   vx      vy      vz   \n');
fprintf(1,'------------------------------------------------------------------------------------------------------\n');
fprintf(outfile,'-------------------------------------------------------------------------------------------------------\n');
fprintf(outfile,' Nr.      JD_Epoch           r[km]       rx        ry        rz        v[km/s]    vx      vy      vz   \n');
fprintf(outfile,'-------------------------------------------------------------------------------------------------------\n');
%   ----------------- Startup propagation -------------------
    while (~feof(infile))
        longstr1 = fgets(infile, 130);
        while ( (longstr1(1) == '#') && (feof(infile) == 0) )
            longstr1 = fgets(infile, 130);
        end

        if (feof(infile) == 0)
            
            longstr2 = fgets(infile, 130);

            [satrec] = twoline2rv( whichconst, ...
                       longstr1, longstr2, typerun, typeinput);  
           
			% Sats Epoch read from TLE's
			JDsat = satrec.jdsatepoch;
            
            % Delta time in minutes
            tsince = (JDeph-JDsat)*1440e0;

%            Call the propagator 
            [satrec, ro ,vo] = sgp4 (satrec,  tsince);
            
            pos= mag(ro); vel=mag(vo); % vectors magnitudes
 
%           Output file/video 
            fprintf(outfile, '%d  %16.8f | %9.3f | %9.3f %9.3f %9.3f | %7.3f | %7.3f %7.3f %7.3f\n',...
                 satrec.satnum, JDsat, pos, ro(1),ro(2),ro(3),vel, vo(1),vo(2),vo(3));
			fprintf(1, '%d  %16.8f | %9.3f | %9.3f %9.3f %9.3f | %7.3f |%7.3f %7.3f %7.3f\n',...
                 satrec.satnum, JDsat, pos, ro(1),ro(2),ro(3),vel, vo(1),vo(2),vo(3));     

        end %// if not eof

    end %// while through the input file

    fclose(infile);
    fclose(outfile);
% --------- EOF: pv_sats.m ----------
% ----- OUTPUT ------------------
