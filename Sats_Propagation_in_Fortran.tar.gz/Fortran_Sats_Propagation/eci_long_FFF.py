# ---- eci_long_FFF.py ---------- Jun.22-26, 2019 ------ FF stands for Final ----
# Source: https://bwinkel.github.io/pycraf/satellite/index.html
from numpy import sqrt, arccos, pi, arctan2
from astropy.coordinates import EarthLocation
from astropy import time
from pycraf import satellite
#
# ECI stands for Earth Center Inertial (frame)
# --------- Step 0 -------------
# Given prediction datetime 
year=2019; month=6; day=29; utch=11; utcm=3; utcs=57
print ('\n Prediction date: ', year, month, day )
print (' Prediction time: ', utch, utcm, utcs, ' UTC' )
print (' ================= ')
# --------- Step 1 -------------
with open ("30giu.txt", "r") as myfile:
    data = myfile.read().splitlines()
for k in range(0,len(data),3):    
	tle= data[k]+'\n'+data[k+1]+'\n'+data[k+2]+'\n'       
	satname, sat = satellite.get_sat(tle)
	print ('\n Name = ', satname,'\n Epoch= ', sat.epoch, '\n Numb = ', sat.satnum)

	# --------- Step 2 ------------
	# using sgp4 directly, to get position and velocity in ECI coordinates
	position, velocity = sat.propagate(year, month, day, utch, utcm, utcs)  
	#
	Dist_geoc= sqrt (position[0]*position[0]+position[1]*position[1]+position[2]*position[2])
	Long_Sat= arctan2(position[1],position[0])
	if Long_Sat < 0.0:
		Long_Sat= Long_Sat + 2*pi
	print (' Position= ', position, ' km')
	print (' r_geocen= {:.3f}'.format (Dist_geoc), ' km')
	print (' Longitude=  {:.4f}'.format (Long_Sat*180/pi), ' degs')
# EOF: eci_long_FFF.py ----------	
'''
28giu.txt [BJ ha i TLE con epoca sicuramente errata 
 44291  19029BJ  Epoch 7 Jun 2019 11: 5:47.38128   JD=2458641.9623539]
---------
 Name =  STARLINK BH
 Epoch=  2019-06-23 20:06:33.651936
 Numb =  44290
 Position=  (6771.701521366504, 1303.1227572275402, -696.965878796731)  km
 r_geocen= 6931.077  km
 Longitude=  10.8926  degs

 Name =  STARLINK BJ
 Epoch=  2019-06-07 11:05:47.381279
 Numb =  44291
 Position=  (nan, nan, nan)  km     (il programma segnala errore)
 r_geocen= nan  km
 Longitude=  nan  degs

 Name =  STARLINK BK
 Epoch=  2019-06-27 05:11:56.727455
 Numb =  44292
 Position=  (5095.192842898613, 3680.756796744558, 2906.363281237037)  km
 r_geocen= 6925.020  km
 Longitude=  35.8443  degs

===============================================================================
30giu.txt [BJ ha i TLE con epoca corretta 
 44291  19029BJ   Epoch 28 Jun 2019 22:40:57.02534   JD=2458663.4451045]
---------
 Name =  STARLINK BH
 Epoch=  2019-06-29 13:07:58.276991
 Numb =  44290
 Position=  (-1355.213422491646, -4262.1234760085545, -5298.435916734078)  km
 r_geocen= 6933.666  km
 Longitude=  252.3611  degs

 Name =  STARLINK BJ
 Epoch=  2019-06-28 22:40:57.025344
 Numb =  44291                       
 Position=  (1630.9316727225473, -3921.3155040793654, -5481.618686312147)  km
 r_geocen= 6934.320  km             (il programma calcola la corretta posizione)
 Longitude=  292.5831  degs

 Name =  STARLINK BK
 Epoch=  2019-06-29 17:45:11.129760
 Numb =  44292
 Position=  (2899.7760915879658, -3518.157271489358, -5225.994145956705)  km
 r_geocen= 6935.211  km
 Longitude=  309.4964  degs

'''
