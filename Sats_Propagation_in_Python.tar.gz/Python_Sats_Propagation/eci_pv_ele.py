# ---- eci_pv_ele.py ---------- Jun.30-Jul.01, 2019 ------ 
# Main source: https://bwinkel.github.io/pycraf/satellite/index.html
# Source for elements calcs: https://github.com/aerospaceresearch/orbitdeterminator [file state_kep.py]
from numpy import sqrt, arccos, pi, arctan2, dot, cross, clip, array
from math import acos, degrees
from astropy.coordinates import EarthLocation
from astropy import time
from pycraf import satellite
#
# ECI stands for Earth Center Inertial (frame)
mu = 398600.4405 # Earth gravitational parameter [km^3/s^2]
# --------- Step 0 -------------
# Given prediction datetime 
year=2019; month=6; day=29; utch=11; utcm=3; utcs=57
print ('\n Prediction date: ', year, month, day )
print (' Prediction time: ', utch, utcm, utcs, ' UTC' )
print (' ================= ')
# --------- Step 1 -------------
with open ("3obj.txt", "r") as myfile:
    data = myfile.read().splitlines()
for k in range(0,len(data),3):    
	tle= data[k]+'\n'+data[k+1]+'\n'+data[k+2]+'\n'       
	satname, sat = satellite.get_sat(tle)
	print ('\n Name = ', satname,'\n Epoch= ', sat.epoch, '\n Numb = ', sat.satnum)

	# --------- Step 2 ------------
	# using sgp4 directly, to get position and velocity in ECI coordinates
	r, v = sat.propagate(year, month, day, utch, utcm, utcs)  

	# --------- Step 3 ------------
	#
	# Computing orbital elements OTTIMO !!!!
	#
	mag_r = sqrt(dot(r,r))  
	mag_v = sqrt(dot(v,v))   
	#
	#
	print (' r_magnit= ', mag_r, ' km')
	print (r, ' km')
	print (' v_magnit= ', mag_v, ' km/s')
	print (v, ' km/s')

	a = 1 / ((2 / mag_r) - (mag_v**2 / mu))
	print ('       a = ', a, ' km')
	#
	h = cross(r, v)
	mag_h = sqrt(dot(h,h))  
	#
	e = cross(v, h) / mu - r / mag_r
	mag_e = sqrt(dot(e,e))
	print (' Eccentr.= ', mag_e, ' ')
	#
	i = acos(clip(h[2] / mag_h, -1, 1))
	i = degrees(i)
	if i >= 360.0:
		i = i - 360
	print ('  Inclin.= ', i, ' degs')
	#
	true_anom = acos(clip(dot(e,r)/(mag_r * mag_e), -1, 1))
	if dot(r, v) < 0:
		true_anom = 2 * pi - true_anom
	true_anom = degrees(true_anom)
	print (' TrueAnom= ', true_anom, ' degs')
	#
	n = array([-h[1], h[0], 0])
	mag_n = sqrt(dot(n,n))
	raan = acos(clip(n[0] / mag_n, -1, 1))
	if n[1] < 0:
		raan = 2 * pi - raan
	raan = degrees(raan) # right ascension
	if raan >= 360.0:
		raan = raan - 360
	print ('    RAAN = ', raan, ' degs')
	#
	per = acos(clip(dot(n, e) / (mag_n * mag_e), -1, 1))
	if e[2] < 0:
		per = 2 * pi - per
	per = degrees(per)
	if per >= 360.0:
		per = per - 360
	print (' ArgPerig= ', per, ' degs')	
	
# EOF: eci_pv_ele.py ----------	
'''

C:\Training\x_eci_pv_ele>python eci_pv_ele.py
WARNING: AstropyDeprecationWarning: astropy.utils.compat.funcsigs is now deprecated - use inspect instead [astropy.
utils.compat.funcsigs]

 Prediction date:  2019 6 29
 Prediction time:  11 3 57  UTC
 =================

 Name =  STARLINK BH
 Epoch=  2019-06-29 13:07:58.276991
 Numb =  44290
 r_magnit=  6933.665921356643  km
(-1355.213422491646, -4262.1234760085545, -5298.435916734078)  km
 v_magnit=  7.57644238427609  km/s
(7.367928372488619, -0.1610445730426039, -1.75788945773786)  km/s
       a =  6923.403686250501  km
 Eccentr.=  0.0015107464813216766
  Inclin.=  52.99124330893892  degs
 TrueAnom=  168.87119780307017  degs
    RAAN =  9.106093762412517  degs
 ArgPerig=  84.25437668126654  degs

 Name =  STARLINK BJ
 Epoch=  2019-06-28 22:40:57.025344
 Numb =  44291
 r_magnit=  6934.320213672662  km
(1630.9316727225473, -3921.3155040793654, -5481.618686312147)  km
 v_magnit=  7.5752836986374925  km/s
(7.298726436778112, 1.8394431010552108, 0.8543796544274769)  km/s
       a =  6922.597171559926  km
 Eccentr.=  0.0016991442780485491
  Inclin.=  52.98960924345745  degs
 TrueAnom=  175.31411363712274  degs
    RAAN =  9.236579780294168  degs
 ArgPerig=  102.81355374111698  degs

 Name =  STARLINK BK
 Epoch=  2019-06-29 17:45:11.129760
 Numb =  44292
 r_magnit=  6935.210651584592  km
(2899.7760915879658, -3518.157271489358, -5225.994145956705)  km
 v_magnit=  7.575246446991064  km/s
(6.811936832940996, 2.6405012692003664, 2.002405644224909)  km/s
       a =  6924.304370351646  km
 Eccentr.=  0.0015752292006502545
  Inclin.=  52.99260403068732  degs
 TrueAnom=  180.80696215081082  degs
    RAAN =  9.2649954945731  degs
 ArgPerig=  108.52221619274525  degs

C:\Training\x_eci_pv_ele>
'''
